# ADR Prompt Engineering Template

ADR-PE-001 Objective
Define artifact and failure conditions

ADR-PE-002 Tool Choice
Model, strengths, weaknesses

ADR-PE-003 Initial Prompt
Original structure

ADR-PE-004 Failures
Expected vs actual

ADR-PE-005 Constraints
Derived from failure

ADR-PE-006 Corrections
Small fixes over rewrites

ADR-PE-007 Invariants
Cross-cutting rules

ADR-PE-008 Locked Prompt
Final version

ADR-PE-009 Freshness
When it expires

ADR-PE-010 Operator Rules
Human judgment layer
