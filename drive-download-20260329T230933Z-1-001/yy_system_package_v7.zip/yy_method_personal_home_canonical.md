# YY Method — Personal/Home Canonical Variant

## Definition

The YY Method — Personal/Home Canonical Variant is a structured method for preserving judgment under constraint in personal systems.

It is designed for situations where life, work, tools, and identity overlap, and where the cost of losing original intent is high. It captures not only what was decided, but why it was decided, what was rejected, what had to be corrected, and what must remain true for the decision to hold.

This variant extends the method from formal organizational and financial decisions into personal operating systems, device architecture, AI workflows, household boundaries, and daily behavior.

## Core Formula

Reality → Constraint → Decision → Rejection → Correction → Commit

## Primary Purpose

- preserve original intent
- prevent convenience drift
- document negative space
- separate capture from classification
- support selective promotion into protected systems
- make judgment transferable without flattening nuance

## Canonical Principles

### 1. Capture broadly
Raw inputs may be broad, messy, and not yet classified.

### 2. Classify deliberately
Captured input does not become actionable truth until reviewed.

### 3. Promote selectively
Only high-signal material should enter protected systems.

### 4. Preserve why
A decision without its reasoning will decay.

### 5. Preserve why-not
Rejected alternatives are part of the truth.

### 6. Record corrections
Truth is often reached through revision. Corrections must be explicit.

### 7. Mark freshness boundaries
Every artifact depends on assumptions that may expire.

### 8. Protect the terminal layer
In protected systems, ingress may be allowed, but leakage must be controlled.

## Standard Layers

### L0 — Identity / Operator
Who is making the judgment and what capabilities they bring.

### L1 — Principles
The stable beliefs shaping the system.

### L2 — Constraints
The rules, limitations, and boundaries that govern options.

### L3 — Decisions
What was chosen.

### L4 — Rejections / Negative Space
What was not chosen and why.

### L5 — Corrections
What changed and what was superseded.

### L6 — Execution Rules
How the decision is applied in practice.

### L7 — Freshness Boundary
When the artifact expires or must be re-evaluated.

## Personal/Home Use Cases

- device and account architecture
- personal / client / employer separation
- family-facing technology boundaries
- AI usage protocols
- capture and promotion systems
- diagrams, prompts, and household decision artifacts
- home operating systems that need to remain legible over time

## Repeatability

The method is repeatable by others.

What is repeatable:
- the structure
- the layers
- the preservation of why, why-not, and corrections
- the use of freshness boundaries
- the distinction between capture and committed truth

What is not automatically repeatable:
- operator quality
- semantic precision
- ability to notice structural error
- discipline in preserving rejected alternatives

The method is teachable.
Mastery is developmental.

## Canonical Test

A Personal/Home YY artifact is successful if it:
- preserves original intent through iteration
- keeps rejected paths visible
- survives correction without losing meaning
- remains understandable to a future self or another human
- prevents protected systems from being polluted by raw input
- documents truth as converged judgment, not first output

## Short Definition

The YY Method — Personal/Home Canonical Variant is a method for preserving judgment under constraint in personal systems by capturing reality, constraints, decisions, rejected alternatives, corrections, execution rules, and freshness boundaries without losing the original intent behind the system.

## Motto

Capture broadly.
Decide deliberately.
Promote selectively.
Protect what must remain clean.
