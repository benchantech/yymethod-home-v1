# YY Unified Framework

Core pattern:
Reality → Constraint → Decision → Rejection → Correction → Commit

Domains:
1. Finance ADRs
2. Device systems
3. AI / prompt systems

Shared layers:
L0 Identity
L1 Principles
L2 Constraints
L3 Decisions
L4 Corrections
L5 Execution
L6 Freshness

Key idea:
ADRs preserve judgment under constraint, not just decisions.
