# Week 1 System Alignment Plan

Objective:
Synchronize team understanding with system reality without overwhelming them.

Core idea:
People only need to understand where they touch the system.

Day 1:
Show system diagram + 3 rules:
- capture vs promote
- no outbound Employer flow
- intentional usage

Day 2–3:
1:1 sessions mapping system to each person’s work.

Day 3–4:
Watch real usage and correct in real time.

Day 4–5:
Reinforce invariants:
- nothing leaves Employer
- promotion is intentional
- don’t guess flows

Day 5:
Identify multipliers and give ownership.

Success:
People use correct flows without asking.
