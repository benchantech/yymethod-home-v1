# Notion Import
Use diagram + memo.