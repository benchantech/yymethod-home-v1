# Executor Contract

## Purpose
Perform sensitive operations outside agent environment.

## Allowed Actions
- deploy_staging
- run_tests
- fetch_metrics_summary

## Forbidden
- expose raw secrets
- arbitrary shell execution

## Interface Example
POST /execute
{
  "action": "deploy_staging",
  "params": {}
}

## Rule
Executor validates request before execution.
