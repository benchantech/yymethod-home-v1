# CLAUDE.md (Agent Rules)

## Allowed
- Read/write code in /workspace
- Run tests
- Create ambiguity reports

## Forbidden
- Access secrets
- Read .env or hidden system files
- Execute deployment directly

## Ambiguity Handling
- Batch all unclear decisions
- Provide options + recommendation

## Principle
Agent proposes, human decides, executor executes.
