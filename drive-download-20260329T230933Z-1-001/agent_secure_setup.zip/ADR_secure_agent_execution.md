# ADR: Secure Agent Execution Model

## Context
Agents previously accessed sensitive files (.env) despite policy constraints.

## Decision
Adopt a hard-boundary architecture:
- Agent runs in isolated container with NO secrets
- Secrets exist only in external executor layer
- Agent interacts via narrow capability interfaces

## Rules
1. If agent can read it, it can leak it
2. No secrets in agent filesystem
3. All sensitive actions go through executor
4. Agent proposes, never finalizes protected actions

## Outcome
Prevents secret leakage and aligns with controlled flow architecture.
