# ADR-014: Employer Discretionary Profit-Sharing Contribution — EOY Bonus Restructure
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided — Pending Founder Conversation  
**Date:** March 29, 2026  
**Depends On:** ADR-007 (combined marginal rate), ADR-011 (Paychex deferral setup)  
**Freshness Boundary:** Expires if: plan document changes, founder's bonus policy changes, nondiscrimination testing creates issues, or annual additions limit is exceeded.

---

## Capture

The founder has an established pattern of issuing year-end discretionary bonuses to all employees — and historically to this operator as a contractor. This pattern is already cognitively ingrained and financially planned for on the founder's side.

The proposal: restructure the EOY bonus as a **discretionary profit-sharing contribution** directly into the employee's 401(k) rather than as W-2 wages. Same dollar amount. Same timing. Different routing. Significant tax benefit to both parties.

Plan administrator: Paychex. Plan likely includes profit-sharing contribution capability — confirm with plan document.

---

## What A Discretionary Profit-Sharing Contribution Is

A profit-sharing contribution is an employer contribution to a qualified retirement plan funded at the employer's discretion. It is:

- **Not tied to employee deferral** — separate from the employee deferral limit ($24,500)
- **Subject to the annual additions limit** (~$71k total for 2026 — employee deferrals + employer contributions combined)
- **Fully deductible** to the employer as a business expense
- **No FICA on either side** — saves 7.65% employee + 7.65% employer = 15.3% combined
- **No income tax to employee** until withdrawal — deferred at current combined rate of 30.85%

---

## The Math — Bonus vs Profit-Sharing

On a $10,000 year-end payment:

| | W-2 Bonus | Profit-Sharing Contribution |
|---|---|---|
| Employee FICA (7.65%) | -$765 | $0 |
| Employer FICA (7.65%) | -$765 (employer cost) | $0 |
| Employee income tax (30.85%) | -$3,085 | Deferred |
| **Net working for employee** | **~$6,150 after tax** | **$10,000 in 401(k)** |
| **Total cost to employer** | **$10,765** | **$10,000** |

The profit-sharing route:
- Saves employee **~$3,850** in immediate tax
- Saves employer **$765** in FICA
- Deploys full $10,000 into tax-deferred growth
- Costs employer **$765 less** than the equivalent W-2 bonus

Both parties win. The dollar amount is identical. The routing is different.

---

## Why This Works Cognitively For The Founder

The founder already:
- Issues discretionary EOY bonuses to all employees
- Has done this historically including to this operator as a contractor
- Has complete discretion over amount and timing
- Is already mentally budgeting for this payment

The ask is not "give me more money." The ask is "route the same money differently." The founder's cognitive load does not increase. His FICA liability decreases. His employee gets a better outcome. The plan document likely already allows it.

This is the lowest-friction high-value conversation available in the employment relationship.

---

## Why-Not

**Why not just take the W-2 bonus?**
At 30.85% combined rate, $10k bonus nets ~$6,150 after tax and FICA. The same $10k as profit-sharing contribution nets $10,000 working tax-deferred. The difference is ~$3,850 in immediate tax plus future compounding on the full $10k vs $6,150. Over 20 years at 7% the gap is enormous.

**What if the plan document doesn't allow profit-sharing contributions?**
Ask the founder to amend the plan to add discretionary profit-sharing. Paychex can facilitate this. The plan amendment is a one-time administrative step with no ongoing complexity.

**What about nondiscrimination testing?**
Profit-sharing contributions must be nondiscriminatory across eligible employees. Since the founder already issues EOY bonuses to all employees, applying the profit-sharing contribution consistently across all eligible participants addresses this. The formula just needs to be consistent — same percentage or same dollar amount per eligible employee. This mirrors the existing bonus pattern exactly.

**What if I'm already near the annual additions limit?**
Annual additions limit ~$71k for 2026. Employee deferrals: $18,375 (cap). Prior S corp employer contribution: ~$13,364. Total so far: ~$31,739. Remaining room: **~$39,261**. A typical EOY bonus of $10-20k fits comfortably within the limit.

**What about the contractor history?**
Prior contractor payments are irrelevant to the W-2 plan. As a W-2 employee the operator is now a plan participant. The profit-sharing contribution flows through the plan, not through the prior contractor relationship.

---

## The Conversation To Have With The Founder

Frame it simply:

> "I wanted to flag something that benefits both of us. When you issue the EOY bonus, if you route it as a profit-sharing contribution to my 401(k) instead of W-2 wages, you save on FICA and I get a much better tax outcome. Same dollar amount, same timing — just different routing through the plan. Worth checking if our plan document already allows it."

That is a 60-second conversation. The founder's likely response: "let me check with Paychex." The follow-up is a plan document review that Paychex can do in a day.

---

## Annual Additions Limit Tracking — 2026

| Contribution | Amount |
|---|---|
| S corp employer contribution (prior) | ~$13,364 |
| Employee deferrals via Paychex (cap) | ~$18,375 |
| Subtotal | ~$31,739 |
| **Remaining room for profit-sharing** | **~$39,261** |
| Annual additions limit | ~$71,000 |

Significant room available for a meaningful profit-sharing contribution.

---

## The Teaching Moment — Employees and Children

Most employees will prefer cash bonus. That preference is not irrational — it reflects a failure to viscerally understand compound interest, combined with heavy discounting of the future in favor of the present. No one has shown them the math on their own money.

This is an opportunity to change that.

**The math, shown plainly:**

| | $10k Cash Bonus | $10k Profit-Sharing |
|---|---|---|
| Take home today | ~$6,150 after tax/FICA | $0 |
| In 401(k) working immediately | $0 | $10,000 |
| After 20 years at 7% | ~$23,800 (taxable account) | **~$38,700 (tax-deferred)** |
| After 30 years at 7% | ~$46,800 | **~$76,100** |

The cash bonus is the expensive choice disguised as the obvious one. The gap widens every year. Showing this math to employees — with their own numbers, not hypothetical ones — is a high-value teaching moment that costs nothing and compounds in ways that don't show up on a balance sheet.

**For the children:**

Four children aging into the LLC, watching their father turn a bonus into a 401(k) contribution and explain why with actual numbers. That is financial literacy that doesn't come from school. It comes from watching a parent who built it himself — the same parent who documented the reasoning, preserved the scars, and left the truth behind him.

This is the KTATI principle — Kid-to-Adult Time Inversion — from the benchantech.com essays applied to money. Adults have minimal time to throw things at walls. When something sticks it has to count. Compound interest inside a tax shelter is one of those high-sticking moments. Show it once, with real numbers, at the right moment. It sticks for decades.

**The violin analogy:**
Compound interest is deliberate practice with money. Small inputs, consistent discipline, long time horizon, exponential output. The mechanism is identical. The instrument is different.

Building in plain sight — for employees, for children, for anyone watching — is the whole point.

---

## Critical Risk — Nondiscrimination Testing

### The HCE Problem

For 2026, a Highly Compensated Employee (HCE) is anyone earning more than $160,000 in 2025 or owning 5%+ of the company. At $300k annualized salary the operator qualifies as an HCE.

Profit-sharing contributions must pass the **ACP (Actual Contribution Percentage) test** — ensuring HCEs don't receive disproportionately large employer contributions relative to Non-Highly Compensated Employees (NHCEs).

### The Trend Breaker Risk

The operator may be the highest-paid employee and potentially the only HCE. If other employees prefer cash and participate minimally in the 401(k), the operator receiving a large profit-sharing contribution creates a situation where HCE contribution percentage dramatically exceeds NHCE percentage — **ACP test failure**.

Failure means corrective distribution — excess returned to operator, taxable in year received, potential 10% excise tax if under 59½. Defeats the purpose entirely.

### Two Questions To Answer Before The Founder Conversation

| Question | Why It Matters |
|---|---|
| Is the plan safe harbor? | Eliminates nondiscrimination testing entirely — proceed confidently if yes |
| What are other employees' 401(k) participation rates? | Low NHCE participation = high ACP failure risk |

### Mitigating Approaches

- **Safe harbor plan:** Clean, no testing, proceed
- **Consistent percentage formula:** Apply profit-sharing as same % of compensation across all eligible employees — NHCEs get smaller dollars but equal percentage, improves test outcomes
- **Auto-enrollment:** If founder is willing, increases NHCE participation and testing headroom — legitimate plan design improvement that benefits everyone

Know both answers before walking into the founder conversation.

---

- Founder maintains EOY bonus pattern into 2026 and beyond
- Paychex plan document allows or can be amended to allow discretionary profit-sharing
- Nondiscrimination testing passes — **verify safe harbor status and NHCE participation rates before executing**
- Annual additions limit not exceeded — confirm contribution amounts before executing
- Operator remains W-2 employee through EOY — not reverted to contractor status

---

## Tribal Context

**Operator supplied:** The question itself — whether the founder could redirect the bonus as an employer contribution rather than W-2 wages. The context that the founder already issues EOY bonuses to all employees including the operator as a contractor historically. The cognitive framing — that this is not a new ask but a new routing, which makes it easy for the founder. The teaching moment angle — using the decision as live curriculum for employees and children simultaneously.

**Model supplied:** The profit-sharing contribution mechanics — no FICA on either side, annual additions limit vs deferral limit distinction, nondiscrimination testing requirement, plan document verification requirement. The quantified comparison table (W-2 bonus vs profit-sharing over 20 and 30 years). The KTATI connection back to the operator's own essay.

The strategy question and the founder framing were entirely the operator's. The model supplied the compliance mechanics and the arithmetic that sized the benefit.

---

## Commit

**Decision:** Raise profit-sharing contribution routing with founder at next appropriate opportunity. Frame as mutual benefit — founder saves FICA, employee gets full tax deferral. Ask founder to verify plan document allows discretionary profit-sharing or request Paychex plan amendment. Execute for 2026 EOY bonus if timing and plan document allow. Repeat annually. Monitor annual additions limit each year before execution.

**Status:** Pending founder conversation.
