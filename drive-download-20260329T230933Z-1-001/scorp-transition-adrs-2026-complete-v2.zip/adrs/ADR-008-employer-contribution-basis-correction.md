# ADR-008: Employer 401(k) Contribution Basis — Correction to Prior Calculations
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided — Correction to ADR-002, ADR-006  
**Date:** March 29, 2026  
**Depends On:** ADR-002, ADR-003, ADR-006  
**Freshness Boundary:** Permanent correction record. Numbers are final as of March 29, 2026.

---

## Capture

A material calculation error was identified and corrected during the planning session on March 29, 2026.

**The error:** Prior calculations applied the 25% employer 401(k) contribution against **total W-2** (salary + bonus combined) in the bonus optimization math — despite the fact that the employer contribution on the $30k salary had **already been made and funded** earlier in Q1.

**The correction:** The remaining employer contribution available before March 31 is **25% of the bonus only**. The $30k salary contribution ($7,500) is already gone — already in Ascensus, already sheltered.

**Who caught it:** The operator. Not the model.

---

## Why This Matters

Applying 25% to total W-2 instead of incremental bonus produced two errors:

1. **Understated the available bonus** — the cash envelope was being incorrectly consumed by a phantom employer contribution on already-paid salary
2. **Understated total employer contribution** — the prior $7,500 was being recounted rather than treated as sunk

The corrected math produces a **larger bonus** because the full cash envelope now goes toward bonus + bonus employer contribution only, with no salary contribution to fund.

---

## Corrected Math

Constraint: bonus + (25% × bonus) + (2.9% × bonus) = available cash  
Simplified: bonus × 1.279 = available cash

**With $30k available:**

| Item | Amount |
|---|---|
| Bonus | ~$23,456 |
| Employer 401(k) on bonus (25%) | ~$5,864 |
| Medicare (2.9%) | ~$680 |
| Cash consumed | ~$30,000 |
| Prior employer contribution (already made) | $7,500 |
| **Total employer 401(k) 2026** | **~$13,364** |
| Combined tax savings (30.85%) | **~$4,122** |

**With $40k available (wire lands):**

| Item | Amount |
|---|---|
| Bonus | ~$31,274 |
| Employer 401(k) on bonus (25%) | ~$7,819 |
| Medicare (2.9%) | ~$907 |
| Cash consumed | ~$40,000 |
| Prior employer contribution (already made) | $7,500 |
| **Total employer 401(k) 2026** | **~$15,319** |
| Combined tax savings (30.85%) | **~$4,721** |

---

## Why-Not

**Why not leave the prior calculation standing?**  
It was wrong. The prior calculation double-counted the salary employer contribution by including it in the bonus optimization constraint. Leaving a wrong number in a knowledge artifact is worse than the correction — especially one that would be fed to payroll execution.

**What was the impact of the error?**  
The error understated the optimal bonus amount. The corrected bonus (~$23-31k) is larger than the previously calculated bonus (~$17-25k) because the cash envelope is more efficiently utilized when only the incremental contribution is applied.

---

## The Scar

This error was caught by the operator — a self-taught CTO/COO/CFO — not by the model. The model applied 25% to total W-2 across multiple calculation passes without flagging that the salary employer contribution was already funded. The operator caught it on the third or fourth pass through the numbers.

This is consistent with the YY Method's position on AI and knowledge systems: **Human captures. AI reads.** The model is useful for structuring, synthesizing, and calculating — but the human must verify the assumptions embedded in the calculations, not just the arithmetic.

The correct mental model for employer 401(k) contribution optimization when mid-year contributions have already been made:

> Only the **incremental** W-2 drives the remaining contribution. Prior periods are sunk. The optimization runs against the marginal cash and marginal compensation only.

---

## Assumptions This Decision Depends On

- $7,500 employer contribution is confirmed funded and received by Ascensus
- No additional employer contributions were made beyond the $7,500 on $30k salary
- 2026 annual addition limit (~$71-72k total) is not a binding constraint at these levels — confirmed well below ceiling

---

## Cascade

ADR-002 and ADR-006 bonus and employer contribution figures should be read in conjunction with this ADR. The corrected numbers here supersede the bonus amounts in those documents.

---

## Commit

**Decision:** Employer contribution basis for bonus optimization is **bonus only** — 25% of the incremental bonus amount. Prior $7,500 salary contribution is sunk and excluded from the optimization constraint. Correct bonus targets: ~$23,456 ($30k scenario) and ~$31,274 ($40k scenario). Total 2026 employer 401(k): ~$13,364 and ~$15,319 respectively.
