# ADR-011: Paychex Flex Deferral Setup & Dollar Cost Averaging Strategy
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided — Pending Execution Monday March 30  
**Date:** March 29, 2026  
**Depends On:** ADR-003, ADR-007, ADR-010  
**Freshness Boundary:** Expires when annual cap is hit (~October 2026). Re-evaluate every September for following year. Expires if salary, pay frequency, or IRS limits change.

---

## Capture

New employer uses **Paychex Flex** for payroll. Start date March 16, 2026. First paycheck ~April 11 (March 16-29 period paid in arrears). Second paycheck ~April 25 — first one not yet received.

Payroll has not yet run for the current biweekly period — deferral election submitted now will take effect on or before April 25.

Key facts:
- Annual salary: $300k
- Biweekly gross: $11,538
- Biweekly pay periods remaining in 2026: ~19
- 2026 employee deferral limit: $24,500
- Already deferred via S corp Q1 salary (3 payrolls at 1/12 each): **~$6,125**
- Remaining available to defer: **$18,375**
- S corp election revoked — **5-year re-election lockout through 2030** — full $24,500+ available every year with no S corp deferral to subtract

---

## The Paychex Flex Setup

Two fields must be set correctly:

| Field | Value | Why |
|---|---|---|
| Deferral percentage | **10%** | DCA across ~16-19 paychecks |
| Annual maximum amount | **$18,375** | Hard stop — prevents excess deferral |

**Critical:** Paychex Flex has no visibility into external plan deferrals (solo 401(k) via S corp). It will not auto-stop at the IRS limit based on outside contributions. The annual maximum cap field is the only protection against excess deferral. Without it, Paychex would allow up to $24,500 through its own plan alone — producing a combined excess of ~$6,125 that would be taxed twice.

---

## How To Set It In Paychex Flex

**Deferral percentage:**
- Log into Paychex Flex
- Select My Retirement
- Elect deferral percentage: **10%**
- Set Annual Maximum Amount: **$18,375**
- Submit

**Additional withholding (Step 4c):**
- Employee → Compensation → Tax Status
- Step 4(c) Extra Withholding: **$500 flat per paycheck**
- Submit — goes through HR approval, allow 1-2 business days

**Note:** Deferral changes take effect within two business days. Submit Monday March 30 to catch April 25 paycheck.

---

## Why 10% — The Dollar Cost Averaging Argument

The instinct to front-load contributions (20%+) in a down market is understandable but flawed in a volatile year. Dollar cost averaging across the full year produces a lower average entry price than concentrated front-loading because:

- Entry price is unknown — the bottom may not be in
- Spreading across ~16 paychecks captures multiple price points through the recovery
- Maximum DCA benefit with minimum take-home disruption
- Cap still protects the annual limit regardless of percentage

At 10%:
- $1,154 per check
- Cap hit in ~16 paychecks — approximately October 2026
- Contributions spread across the full volatile year
- Take-home comfortable throughout

---

## Why-Not

**Why not 20% to front-load the down market?**  
Concentrates contributions into 8 paychecks. Assumes the market doesn't go lower. Reduces take-home significantly during the front-loading period. DCA across a volatile year is the superior risk-adjusted approach when the bottom is uncertain.

**Why not set percentage without the annual cap?**  
Paychex has no visibility into the $6,125 already deferred via S corp. Without the cap, contributions continue until Paychex hits $24,500 on its own — producing $6,125 in excess deferrals taxed twice. The cap is non-negotiable.

**Why not dollar amount instead of percentage?**  
Paychex Flex only accepts percentage-based deferrals for employee elections. Dollar amounts are not an option.

---

## The Full 2026 DCA Picture

Contributions deployed across the entire year at multiple price points:

| Period | Contribution | Market Context |
|---|---|---|
| Q1 S corp salary deferrals | ~$6,125 | Pre-transition prices |
| Q1 S corp employer contribution | ~$13,364 | March — market down |
| April–October employer deferrals (10%) | ~$18,375 | Spread across recovery/volatility |
| SEP-IRA for LLC SE income | ~$3,450 | Funded at 2026 tax filing |
| **Total 2026 retirement contributions** | **~$41,314** | Full year DCA |

This DCA structure emerged naturally from the entity transition mechanics — not from deliberate timing. The result is near-ideal market exposure across a volatile year without any active timing decisions.

---

## Tax Savings Summary

| Contribution | Combined Rate | Tax Saved |
|---|---|---|
| ~$41,314 total contributions | 30.85% | **~$12,745** |

---

## Annual September Update Rhythm

Every September, 5-minute login:

| Year | Action | IRS Limit (est.) | Cap To Set |
|---|---|---|---|
| Sep 2026 | Set 2027 election | ~$25,000 | ~$25,000 (no S corp) |
| Sep 2027 | Set 2028 election | ~$25,500 | ~$25,500 |
| Sep 2028 | Set 2029 election | ~$26,000 | ~$26,000 |
| Sep 2029 | Set 2030 election | ~$26,500 | ~$26,500 |
| Sep 2030 | Set 2031 election | ~$27,000 | ~$27,000 or adjust if S corp re-evaluated |

**Note:** S corp re-election not available until 2031 at earliest. Full annual limit available every year through 2030 — no S corp deferral to subtract. Confirm IRS limit announcement each October/November before setting cap.

---

## Assumptions This Decision Depends On

- Salary remains $300k — biweekly gross $11,538
- Pay frequency remains biweekly — 26 periods per year
- Paychex Flex remains employer's payroll system
- 2026 IRS deferral limit confirmed at $24,500
- No S corp re-election through 2030 — confirmed by 5-year lockout rule
- $6,125 S corp deferral amount is accurate — 3 payrolls × $2,042

---

## Tribal Context

The DCA insight came from the operator — not the model. The model defaulted to front-loading logic (higher percentage = more capital deployed in down market sooner). The operator correctly identified that in a volatile year, spreading contributions across the full year via DCA produces a better average entry price than concentration.

The annual cap field is the most important technical detail in this ADR. It is the only mechanism preventing an excess deferral situation that would create a tax problem. It must be set correctly on day one and verified each September update.

The 5-year re-election lockout — also caught by the operator — fundamentally simplifies the annual September update through 2030. No S corp math. No partial year calculation. Just update the IRS limit and keep the percentage at 10-15%.

---

## Commit

**Decision:**  
- Paychex Flex deferral: **10%, annual cap $18,375**  
- Additional withholding Step 4(c): **$500 per paycheck**  
- Submit Monday March 30 morning  
- Update every September — confirm IRS limit, reset cap to full annual limit  
- Keep percentage at 10-15% for DCA benefit  
- 5-year S corp lockout means full annual limit available every year through 2030 — no adjustments needed for S corp deferrals
