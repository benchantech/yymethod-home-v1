# ADR-006: Cash & Banking Execution — Live Oak Wire Contingency
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided  
**Date:** March 29, 2026  
**Depends On:** ADR-002, ADR-003  
**Freshness Boundary:** Expires March 31, 2026 upon execution. Permanently stale after that date.

---

## Capture

Cash position as of March 29, 2026:
- **Main LLC bank:** $30k — already linked to Ascensus 401(k) plan, proven ACH history
- **Live Oak Bank:** $10k — proven ACH history to main LLC bank (large transfer ~1 month prior)

Total available: $40k

Execution requires:
- Bonus payroll funded from main LLC bank (payroll pulls from main)
- Employer 401(k) contribution funded from main LLC bank to Ascensus
- Medicare taxes deposited on S corp EIN

The question: should the $10k in Live Oak be incorporated into the execution, and if so, how?

---

## Why the $10k Matters

With $30k in main, the bonus ceiling is approximately $17-18k with employer contribution of ~$11,750-12,000.

If the $10k from Live Oak lands in main before execution:
- Total available rises to $40k
- Bonus ceiling increases to ~$22-24k
- Employer contribution increases to ~$13,500-15,000
- Additional tax shelter: ~$800 in federal tax savings at 32%
- Additional benefit: deploying ~$2,500 more capital into a down market inside a tax-deferred wrapper

The market timing angle strengthens the case: contributions made during a market downturn buy more units at lower prices, compounding the benefit over time inside the tax shelter.

**$1k cash reserve — considered and rejected.** A $1k reserve was initially considered. Rejected because April 1 the entity becomes a disregarded entity — cash moves freely with zero friction. Credit card float covers any immediate expenses. Employer paycheck begins immediately. Holding $1k back solves a problem that expires in 24 hours. Full amount deployed.

---

## Why-Not

**Why not wire immediately (Sunday March 29)?**  
Live Oak has no weekend customer support. Wires initiated Sunday are unlikely to process until Monday. ACH initiated Sunday settles Tuesday at earliest — potentially after the March 31 deadline.

**Is the wire guaranteed same-day if initiated Monday?**  
No. Live Oak does not explicitly guarantee same-day domestic wire delivery. Settlement depends on Live Oak's internal processing cutoff, the receiving bank's processing, and Fedwire operating hours. The wire is typically same-day if initiated before cutoff (~noon ET) but is not contractually guaranteed.

**Why not build the March 31 execution plan around the wire?**  
Building a hard-deadline execution around a non-guaranteed transfer is unnecessary risk when $30k is already sitting in the correct account. The $10k is additive, not foundational.

---

## The Conditional Execution Model

Rather than treating the wire as required, the decision was to treat it as **conditional and additive**:

1. **Monday morning** — initiate $19 outgoing domestic wire from Live Oak to main LLC bank
2. **Tuesday March 31** — check main bank balance before executing anything
3. **If wire landed** — execute with full ~$40k picture, maximize bonus and employer contribution
4. **If wire did not land** — execute cleanly with $30k, no stress, slightly lower bonus and employer contribution

This converts a binary timing risk into a simple conditional check. Either branch produces a valid, complete execution. The wire failure path is not a degraded outcome — it was the baseline plan all along.

---

## Live Oak Wire Facts (Verified)

- Outgoing domestic wire fee: **$19**
- ACH transfers: free, 1-2 business days, 5PM ET cutoff
- No weekend customer support
- Wire transfers: same-day domestic typically available on business days
- $19 fee on ~$10k transfer = 0.19% — trivially small relative to tax benefit

---

## Why the Wire Is Worth Initiating

Even without a guarantee, the expected value is positive:
- Cost: $19 + 10 minutes Monday morning
- Upside if lands: ~$800 tax savings + down-market deployment of ~$2,500 additional capital
- Downside if doesn't land: $19 wire fee, execution proceeds on $30k baseline

The asymmetry strongly favors initiating the wire.

---

## Assumptions This Decision Depends On

- Main LLC bank already has established Ascensus contribution link — confirmed by prior usage
- Live Oak wire cutoff on Monday allows same-day processing — verify Monday morning
- March 31 is a business day — confirmed (Tuesday)
- $30k in main is sufficient to execute the baseline plan — confirmed

---

## Tribal Context

This decision was reached through a sequence of questions and answers in real time on March 29. The key insight was that the conditional execution model — check the balance, branch accordingly — eliminates the timing risk entirely without sacrificing the upside. 

The person making this decision thought like an engineer: identify the condition, define both branches, execute the branch that matches state. No heroics, no dependency on uncertain outcomes.

The market timing observation — contributions into a down market inside a tax shelter compound the benefit — came unprompted. It reflects the kind of multi-variable thinking that separates optimized financial decision-making from mechanical compliance.

---

## Commit

**Decision:**  
1. Initiate $19 domestic wire from Live Oak → main LLC bank, Monday March 30 morning before noon ET cutoff  
2. Tuesday March 31: check main bank balance  
3. If wire landed: execute payroll + Ascensus contribution using full ~$40k  
4. If wire did not land: execute payroll + Ascensus contribution using $30k baseline  
5. Either branch: execution is complete, S corp is closed cleanly
