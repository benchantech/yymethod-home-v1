# ADR-012: Minor Child Employment — LLC Disregarded Entity
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided — Pending Verification of NY Workers Comp Exemption  
**Date:** March 29, 2026  
**Depends On:** ADR-001 (disregarded entity structure), ADR-007 (combined marginal rate)  
**Freshness Boundary:** Expires if: NY workers comp rules change, child turns 18, IRS standard deduction changes, business activity changes from clerical/AI work, or work location changes from home office.

---

## Capture

Four minor children to be employed by the LLC (disregarded entity / SMLLC) on a staggered basis as each ages into capability for clerical work and AI automation tasks performed under parental supervision in the home office. Work is sedentary, non-hazardous, and entirely administrative in nature.

Entity structure: Single-member LLC treated as disregarded entity (sole proprietorship) for tax purposes effective April 1, 2026.

**This was a deliberate tactical decision** — not an accidental byproduct of the S corp revocation. The 5-year re-election lockout (2026-2030) was recognized as the enabling condition for the FICA exemption on family employment. The S corp structure would have blocked this benefit entirely. The revocation opened the window. The family employment strategy fills it.

---

## The Work Defined

- **Nature:** Clerical and AI automation assistance
- **Location:** Home office — parent-supervised at all times
- **Hazard level:** Zero — sedentary desk work, no equipment, no travel, no customer contact
- **Supervision:** Direct parental supervision throughout

This definition matters for both NY workers comp exemption analysis and IRS scrutiny of the employment arrangement.

---

## Federal Tax Treatment

Wages paid by a sole proprietor / disregarded SMLLC to a minor child under 18 receive favorable treatment:

| Item | Treatment |
|---|---|
| FICA (Social Security + Medicare) | **Exempt** — child under 18 employed by parent's sole prop |
| FUTA | **Exempt** — child under 18 employed by parent |
| Federal income tax on child's wages | **Zero** up to standard deduction (~$15,000) |
| Parent's business deduction | **Full deduction** — ordinary and necessary business expense |

The child must perform **legitimate, documented work** at **reasonable market wages** for the tasks performed. IRS scrutiny is real — the work must be real, the rate must be defensible.

---

## The Tax Benefit — Per Child And Full Pipeline

**Per child employed (up to standard deduction ~$15,000):**

| Component | Amount |
|---|---|
| Wages paid to child | ~$15,000 |
| Child's federal income tax owed | $0 |
| Parent's deduction at 30.85% combined | **~$4,628 saved** |
| FICA saved (no FICA on these wages) | **~$2,138 saved** |
| **Total family tax benefit per child** | **~$6,766** |

**Full pipeline — all 4 children employed:**

| Children Employed | Annual Family Tax Benefit |
|---|---|
| 1 | ~$6,766 |
| 2 | ~$13,532 |
| 3 | ~$20,298 |
| 4 | **~$27,064** |

~$27k in annual recurring tax savings at full deployment. Legitimate. Documented. Fully defensible. Compounds annually through at least 2030.

---

## NY Workers Comp Analysis

**General rule:** NY requires workers compensation coverage for employees including family members.

**Exemption applicable here:**
- Sole proprietors and their family members working in the family business have specific exemptions under NY Workers Compensation Law
- A minor child performing clerical work in a parent's home-based sole proprietorship / disregarded SMLLC is generally exempt
- The home office location, sedentary nature of work, and direct parental supervision all strengthen the exemption case
- **Hazardous activity** would remove the exemption — clerical/AI work does not qualify as hazardous

**Status:** Exemption appears applicable — must be **verified with NY Workers Compensation Board or insurance broker** before employment begins. Rules have conditions and are subject to change.

---

## Why-Not

**Why not pay more than the standard deduction?**  
Wages above ~$15,000 trigger federal income tax on the child at their rate — still likely lower than parent's 30.85% but adds complexity and filing requirements. Start at the standard deduction limit, evaluate upward as work warrants.

**Why not use an S corp for the employment?**  
S corp election revoked — 5-year lockout through 2030. Disregarded entity is the only available structure. Fortunately the FICA exemption applies to disregarded entity employment of minor children — this would NOT apply if the employer were an S corp or C corp.

**Why not hire through the employer W-2 relationship?**  
Not possible — the child is employed by the LLC, not the corporate employer. The LLC is the business entity generating the deductible wages.

**Why not pay informally without a payroll setup?**  
IRS requires legitimate employment documentation:
- Written job description
- Timesheets or work logs
- Age-appropriate wage rate defensible at market
- Actual payment — check or direct deposit, not cash
- W-2 issued at year end
- Child's own bank account recommended

Informal payment without documentation invites recharacterization and penalties.

---

## Documentation Requirements

To withstand IRS scrutiny:

| Document | Requirement |
|---|---|
| Job description | Written, specific to clerical/AI tasks performed |
| Work log | Hours worked, tasks completed, dated |
| Wage rate | Reasonable for age and task — research market rate for clerical/admin work |
| Payment method | Check or direct deposit — not cash |
| W-2 | Issued by January 31 following year |
| Child's bank account | Separate account in child's name — demonstrates legitimate payment |

---

## The Legitimate Work Standard

Clerical and AI automation work in a home office is legitimate and defensible for a minor child if:

- Tasks are real and documented — filing, data entry, research, AI prompt assistance, scheduling, document organization
- Hours are reasonable for age and school schedule
- Rate is comparable to what you would pay a non-family member for the same work
- Work product is retained as evidence

AI automation assistance is particularly defensible in 2026 — it is a real, emerging skill set with market value. A minor child trained to assist with AI workflows is performing legitimate business services.

---

## Assumptions This Decision Depends On

- Child is under 18 for the full employment period
- Work remains strictly clerical/AI — no hazardous activities
- Location remains home office under direct parental supervision
- NY workers comp exemption verified before employment begins
- Wages do not exceed standard deduction in first year (~$15,000)
- IRS standard deduction remains ~$15,000 for single filers
- Documentation maintained contemporaneously — not reconstructed after the fact

---

## Tribal Context

This strategy was deliberate — not accidental. The operator recognized that the S corp revocation created the enabling condition for the FICA exemption on family employment. An S corp or C corp employer cannot use this exemption. A disregarded entity can. The 5-year lockout, initially noted as a constraint, was understood from the outset as the tactical entry point for a multi-year family employment strategy spanning all four children.

Four children aging into capability over the 2026-2030 window means the annual benefit scales from ~$6,766 with one child to ~$27,064 with all four employed — recurring, compounding, fully defensible with proper documentation.

The clerical/AI work definition is intentional — honest, defensible, age-appropriate, and aligned with actual work the children can perform. AI automation assistance is a legitimately valued skill set in 2026. As each child develops capability, the scope and wage justification grows with them.

The 2031 S corp re-election decision will need to weigh the FICA savings of S corp distributions against the loss of the family employment FICA exemption. At ~$27k in annual family tax benefit, the S corp re-election calculus is not automatic — the family employment benefit may outweigh it depending on income composition at that time.

---

## Pending Actions

1. **Verify NY workers comp exemption** — contact NY Workers Compensation Board or insurance broker before employment begins
2. **Draft job description** — specific to clerical and AI automation tasks
3. **Open child's bank account** if not already established
4. **Set up payroll** — add child as employee to LLC payroll, withhold appropriately (likely $0 federal/state given wage level)
5. **Establish work log** — contemporaneous documentation from day one

---

## Commit

**Decision:** Employ all four minor children through disregarded entity LLC for clerical and AI automation work under direct parental supervision in home office. Stagger employment as each child ages into capability. Pay each up to standard deduction (~$15,000). Capture up to ~$27,064 in combined family tax benefit annually at full deployment. Document rigorously — job description, work logs, market-rate wages, W-2s. Verify NY workers comp exemption before first child's employment begins. Revisit wage levels annually as work scope and each child's age and capability grow. At 2031 S corp re-election evaluation, weigh family employment FICA benefit (~$27k) against S corp distribution FICA savings before re-electing.
