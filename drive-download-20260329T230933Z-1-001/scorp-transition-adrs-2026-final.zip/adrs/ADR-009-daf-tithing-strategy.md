# ADR-009: Donor Advised Fund — LDS Tithing Front-Load Strategy
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided — Pending Execution Timing  
**Date:** March 29, 2026  
**Depends On:** ADR-007 (bracket analysis), ADR-004 (taxable account distributions)  
**Freshness Boundary:** Expires if: AGI limits change, DAF rules change, tithing obligation changes, bracket progression timeline shifts, or taxable account composition changes materially.

---

## Capture

Annual LDS tithing obligation creates a known, recurring charitable commitment. Currently paying from cash annually — capturing no incremental tax benefit beyond standard deduction on MFJ (~$30k for 2026).

Taxable brokerage account holds appreciated securities originally funded by Q1 S corp distributions. Embedded gains exist and will eventually be taxed unless strategically managed.

A Donor Advised Fund (DAF) allows front-loading multiple years of tithing in a single contribution, unlocking itemization in the contribution year, deferring grants to the church over subsequent years, and eliminating capital gains on contributed appreciated securities.

---

## The Core Mechanics

- Contribute appreciated securities (or cash) to DAF in a single lump sum
- Receive **full fair market value charitable deduction** in contribution year
- **Zero capital gains** on contributed appreciated securities
- **Cost basis reset** — reinvest in taxable account at current prices
- Grant from DAF to LDS church annually on normal tithing schedule
- Church receives same amount on same schedule — operationally unchanged
- DAF balance grows **tax-free** until granted

---

## Why — The Itemization Unlock

Standard deduction MFJ ~$30k means annual tithing payments produce no incremental tax benefit — the standard deduction already exceeds typical annual deductions. Front-loading 5+ years of tithing into a DAF in a single year blows past the standard deduction threshold and converts years of untaxed tithing into a single large itemized deduction.

The reversion strategy (bunching):
- **Contribution year:** Itemize with large DAF contribution
- **Subsequent years:** Take standard deduction while granting from DAF
- **Repeat** when DAF depletes

---

## The Two-Phase Strategy

**Phase 1 — 2026 at 30.85% combined rate**

| Item | Amount |
|---|---|
| Annual tithing (~10% of income) | ~TBD based on confirmed amount |
| 5 years front-loaded into DAF | ~$150k (estimated) |
| Standard deduction MFJ | ~$30k |
| Excess itemized deduction | ~$120k |
| Tax savings at 30.85% | **~$37,020** |
| 2027-2031: grant $30k/yr from DAF | Church funded, standard deduction taken |

**Phase 2 — 2027/2028 at ~38.85% combined (32% federal target)**

| Item | Amount |
|---|---|
| DAF depleted — front-load again | ~$150k |
| Tax savings at 38.85% | **~$58,275** |
| Delta vs Phase 1 | **+$21,255 more savings** on same dollars |

**Total across both phases vs paying annually with standard deduction:**

| Approach | Tax Savings |
|---|---|
| Annual cash tithing, standard deduction | ~$0 incremental |
| Two-phase DAF front-load | **~$95,000+** |

---

## The Appreciated Securities Compounding Effect

Contributing appreciated securities instead of cash produces a triple benefit:

1. **No capital gains** on embedded appreciation — gain evaporates at contribution
2. **Full FMV deduction** — deduct the appreciated value, not the cost basis
3. **Basis reset** — reinvest in taxable account at current market prices, starting fresh

Executed across two phases this becomes a **perpetual gain harvesting mechanism** — the taxable account never accumulates large embedded gains because each DAF front-load strips them out.

---

## Why-Not

**Why not just pay tithing annually from cash?**  
Zero incremental tax benefit. Standard deduction absorbs the annual tithing amount. Every dollar paid from cash is an after-tax dollar with no shelter. The DAF strategy converts the same obligation into a significant tax event.

**Why not wait for Phase 2 (higher bracket) before executing Phase 1?**  
Two arguments against waiting:
- A dollar saved in 2026 compounds from 2026. The bracket premium in Phase 2 must overcome the time value of Phase 1 savings.
- Market is currently down — appreciated securities have less embedded gain, meaning more shares can be contributed at lower FMV for the same deduction value. Resetting basis during a downturn is advantageous.

Counter-argument for waiting: every dollar of Phase 1 deduction is worth 8 cents more at 38.85% vs 30.85%. If the tithing front-load is large enough, the premium is material.

**Resolution:** Execute Phase 1 in 2026 if tithing amount and income are confirmed. The compounding advantage of early execution and the down-market basis reset outweigh the bracket premium for waiting — unless income composition for 2027 is highly certain.

**Why not contribute cash instead of securities?**  
Securities are superior when appreciated:
- Avoid capital gains entirely
- Deduct full FMV
- Reinvest cash in taxable account at reset basis
- Cash contributions have a higher AGI limit (60%) vs securities (30%) — but at current AGI levels both are sufficient

---

## AGI Limit Constraints

| Contribution Type | AGI Limit | Available at ~$265k AGI |
|---|---|---|
| Appreciated securities to DAF | 30% of AGI | ~$79,500 per year |
| Cash to DAF | 60% of AGI | ~$159,000 per year |
| Excess | Carries forward 5 years | No waste |

A large front-load may exceed the 30% securities limit in year one — remainder carries forward 5 years and is not lost.

---

## Timing Decision — Open

Phase 1 execution year (2026 vs 2027) depends on:
- **Confirmed annual tithing amount** — drives front-load size
- **2027 income certainty** — if 32% federal is highly likely, Phase 1 at 38.85% captures more value
- **Current taxable account appreciation** — down market argues for executing now
- **DAF account setup** — Fidelity Charitable, Schwab Charitable, or Vanguard Charitable are the primary custodians; setup is fast

---

## Tribal Context

This strategy emerged from a throwaway observation — distributions deployed into taxable account had grown — and evolved into a sophisticated two-phase tax optimization tied to a known recurring obligation. The LDS tithing structure is uniquely well-suited to DAF front-loading because the obligation is perpetual, predictable, and the church is an established 501(c)(3).

The bracket progression insight — executing Phase 1 now and Phase 2 at the higher bracket — turns a one-time tax strategy into a repeating cycle that gets more valuable as income grows. This is the kind of compounding that results from thinking about the tax system as a set of rules to be understood and utilized rather than a cost to be minimized reactively.

---

## Assumptions This Decision Depends On

- LDS church maintains 501(c)(3) status — contribution remains deductible
- DAF custodian accepts securities transfers from taxable brokerage
- AGI remains sufficient to absorb deduction within limits or carry-forward rules apply
- Tithing obligation continues — DAF front-load is predicated on known future grants
- Bracket progression to 32% federal materializes in 2027/2028 for Phase 2

---

## Commit

**Decision:** Execute two-phase DAF front-load strategy. Phase 1 in 2026 using appreciated taxable account securities. Phase 2 when 32% federal bracket is reached. Confirm annual tithing amount to size the front-load. Open DAF account at Fidelity Charitable, Schwab Charitable, or Vanguard Charitable. Contribute securities, not cash, to maximize triple benefit. Revert to standard deduction in intervening years while granting from DAF annually.

**Status:** Pending confirmation of annual tithing amount and Phase 1 vs Phase 2 timing decision.
