# ADR-007: Tax Bracket Reality — Federal + NY State Combined Rate
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided  
**Date:** March 29, 2026  
**Depends On:** ADR-002, ADR-003  
**Freshness Boundary:** Expires if filing status changes, NY state tax rates change, 2026 federal brackets are revised, or income composition changes materially.

---

## Capture

The optimization analysis was initially framed around a 32% federal marginal rate. Mid-conversation, the filing status was confirmed as MFJ with no spouse income — which places 2026 taxable income squarely in the **24% federal bracket**, not 32%.

However, NY State income tax at **6.85%** applies on top of federal. The combined marginal rate is **~30.85%** — effectively 31%. This rate is the correct figure for all optimization calculations.

---

## 2026 Income Composition

| Source | Amount |
|---|---|
| S corp W-2 (salary + bonus) | ~$47-55k |
| Employer W-2 | ~$200k |
| S corp distributions (non-wage) | ~$20-28k |
| LLC SE income (disregarded entity) | ~$15k |
| **Gross total** | **~$282-298k** |

---

## Taxable Income Estimate

| Item | Amount |
|---|---|
| Gross income | ~$282-298k |
| Solo 401(k) employer contribution | ~$11,700-13,900 |
| SEP-IRA (25% of ~$15k net SE) | ~$2,813 |
| SE tax deduction | ~$1,060 |
| AGI | ~$265-280k |
| Standard deduction MFJ (~$30,000) | -$30,000 |
| **Taxable income** | **~$235-250k** |

---

## 2026 MFJ Federal Bracket Thresholds (Estimated)

| Bracket | MFJ Threshold |
|---|---|
| 22% | Up to ~$201,050 |
| 24% | $201,050 — ~$383,900 |
| 32% | $383,900 — ~$487,450 |
| 35% | Above ~$487,450 |

At ~$235-250k taxable income: **24% federal bracket**.  
Gap to 32%: **~$135-150k additional taxable income**.

---

## Why the Combined Rate Is What Matters

Federal bracket alone understates the true marginal cost of each unshielded dollar. NY State tax applies to the same income at 6.85%. Every dollar sheltered into a traditional 401(k) saves:

- Federal: $0.24
- NY State: $0.0685
- **Combined: $0.3085**

Net benefit per bonus dollar sheltered after Medicare FICA:  
$0.3085 − $0.029 = **$0.2795 per dollar**

---

## Revised Total Benefit at 30.85% Combined Rate

| | $30k scenario | $40k scenario |
|---|---|---|
| Employer 401(k) contribution | ~$11,898 | ~$13,853 |
| Combined tax savings (30.85%) | **~$3,670** | **~$4,273** |
| Medicare cost (2.9%) | ~$510 | ~$737 |
| **Net benefit** | **~$3,160** | **~$3,536** |

---

## Why-Not

**Why not use federal rate alone for planning?**  
Understates true marginal rate by 6.85%. At these income levels NY state tax is material — ignoring it produces decisions that are directionally correct but numerically wrong. Combined rate must be used for any optimization calculation.

**Does NYC tax apply?**  
No — NY State only. NYC residents would add ~3.876%, bringing combined rate to ~34.7%. Not applicable here.

---

## 2027 Target: Hitting 32% Federal

The strategic goal is to reach 32% federal bracket in 2027. At that point:

| Combined rate | ~38.85% |
|---|---|
| Net benefit per dollar sheltered | ~$0.359 |
| On same ~$12-14k employer contribution | **~$4,600-5,400 saved** |

That is 30-50% more savings than 2026 on the same contribution infrastructure. The levers to close the ~$135-150k gap to 32%:

- Additional fractional/consulting clients alongside CTO role (if contractually permitted)
- S corp re-election if SE income justifies it
- Spouse income (any amount accelerates bracket progression on MFJ)
- LLC SE income growth beyond current $15k projection

---

## The Scar

The analysis began at 32% federal. The correction to 24% federal happened mid-conversation upon confirming MFJ filing status with no spouse income. The initial optimization logic was directionally correct — the combined NY rate brings the effective marginal rate back to ~31%, close to the original assumption. The decision outcome was unchanged. The number was refined.

This is the kind of correction that gets lost when reasoning isn't preserved. The scar is intentional.

---

## Assumptions This Decision Depends On

- MFJ filing status maintained for 2026
- No spouse income in 2026
- NY State tax rate remains ~6.85%
- Income composition holds to projections above
- No material itemized deductions that would exceed standard deduction

---

## Commit

**Decision:** Use **30.85% combined marginal rate** (24% federal + 6.85% NY) for all 2026 optimization calculations. The 401(k) employer contribution strategy is confirmed correct at this rate. Net benefit of ~$3,160-3,536 is real and material. 2027 target: cross into 32% federal bracket to unlock ~38.85% combined rate and maximize shelter infrastructure already in place.
