# ADR-005: Retirement Vehicle Transition — Solo 401(k) → Dormant → SEP-IRA
**Method:** YY Method™ v2.3 — Capture → Why → Why-Not → Commit → Timestamp  
**Status:** Decided (partially pending — rollover eligibility unconfirmed)  
**Date:** March 29, 2026  
**Depends On:** ADR-001, ADR-003  
**Freshness Boundary:** Expires when employer plan rollover eligibility is confirmed or denied. SEP-IRA path is stable until SE income structure changes.

---

## Capture

After March 31, the solo 401(k) sponsored by the S corp can no longer accept contributions. Three retirement vehicles are in play for the transition:

1. **Solo 401(k)** — existing plan, goes dormant after March 31
2. **Employer 401(k)** — available through W-2 employment starting April 1
3. **SEP-IRA** — available for any self-employment income earned as disregarded entity from April 1

The question: what happens to each vehicle, and in what sequence?

---

## Why — Each Vehicle

**Solo 401(k) → Dormant**  
The plan does not need to be terminated simply because the S corp election ends. It can sit dormant with accumulated balances. No contributions in. Balance grows tax-deferred. Form 5500-SF is required annually only if balance exceeds $250k. If balance stays below $250k, no filing burden.

**SEP-IRA → Opens for SE income**  
Once operating as a disregarded entity, a SEP-IRA is the natural fit for any self-employment income. Zero administrative overhead, no plan document, no Form 5500, funded at tax filing deadline. Contributions capped at 25% of net SE income up to the annual limit (~$70k+). SEP contributions for 2026 will be based only on Schedule C/SE income from April 1 onward — Q1 W-2 wages from the S corp are not included.

**Employer 401(k) → Rollover destination (conditional)**  
If the employer plan accepts incoming rollovers from other qualified plans (check plan SPD/documents), rolling the solo 401(k) into the employer 401(k) is the cleanest outcome: consolidates accounts, eliminates dormant plan, removes Form 5500 risk, and preserves the 401(k) wrapper's stronger creditor protection relative to an IRA in many states.

---

## Why-Not

**Why not terminate the solo 401(k) immediately?**  
No urgency. Termination requires formal plan termination procedures and ultimately a distribution or rollover. Letting it sit dormant while evaluating the rollover option is lower friction and preserves optionality.

**Why not roll solo 401(k) to Traditional IRA immediately?**  
Always available — no deadline. If the employer plan rollover is confirmed as viable, the employer plan is the better destination (creditor protection, keeps 401(k) wrapper). IRA rollover is the fallback if employer plan rejects the rollover.

**Why not keep contributing to solo 401(k) after April 1?**  
Cannot. No W-2 compensation from the sponsoring employer after March 31. No contribution basis exists. The plan is frozen.

**Can Traditional IRA roll into the dormant solo 401(k)?**  
This window closes March 31. Once the S corp terminates, the solo 401(k) has no active participant and most plan documents will not accept incoming rollovers. If this move was desired, it needed to happen before March 31. It was not executed — window is now closed.

---

## The Rollover Hierarchy

| Move | Feasibility | Timing |
|---|---|---|
| Solo 401(k) → Employer 401(k) | Check plan docs — preferred if allowed | Anytime after April 1 |
| Solo 401(k) → Traditional IRA | Always available | Anytime |
| Traditional IRA → Solo 401(k) | Window closed March 31 | Not available |
| New contributions → SEP-IRA | Available for SE income | At tax filing for 2026 |

---

## Assumptions This Decision Depends On

- Solo 401(k) balance remains below $250k (no Form 5500-SF trigger) — monitor annually
- Employer plan SPD permits incoming rollovers from qualified plans — **unverified, must check**
- SE income is generated as disregarded entity from April 1 onward to justify SEP-IRA contributions
- Solo 401(k) custodian (Ascensus) permits dormant status without forced distribution

---

## Tribal Context

The two-vehicle future structure (dormant solo 401(k) + SEP-IRA + employer 401(k) as rollover destination) emerged organically from the conversation. It was not a pre-planned outcome. The SEP-IRA transition is a return to a simpler structure — the S corp and solo 401(k) were the added complexity layer that justified themselves during the consulting years.

The key insight: the employer 401(k) rollover, if available, is the cleanest possible outcome and should be pursued first before defaulting to IRA.

---

## Commit

**Decision:**  
1. Solo 401(k) goes dormant after March 31. No termination yet.  
2. SEP-IRA opens for 2026 SE income. Funded at 2026 tax filing.  
3. Pursue employer plan rollover — request SPD and verify rollover-in eligibility.  
4. If employer plan accepts: roll solo 401(k) → employer 401(k).  
5. If employer plan rejects: solo 401(k) sits dormant, roll to IRA at future convenience.  
6. Monitor solo 401(k) balance annually against $250k Form 5500-SF threshold.
