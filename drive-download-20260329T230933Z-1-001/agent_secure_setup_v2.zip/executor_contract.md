# Executor Contract

## Purpose
Perform sensitive operations outside agent environment.

## Identity
- Executor runs with AWS IAM role
- IAM role may read specific SSM parameters only

## Allowed Actions
- deploy_staging
- run_tests
- fetch_metrics_summary
- get_staging_config_values (filtered, never raw secrets)
- run_db_migration_plan

## Forbidden
- expose raw secrets
- arbitrary shell execution
- unrestricted SSM reads

## Interface Example
POST /execute
{
  "action": "deploy_staging",
  "params": {}
}

## Rule
Executor validates request before execution and logs action + outcome.
