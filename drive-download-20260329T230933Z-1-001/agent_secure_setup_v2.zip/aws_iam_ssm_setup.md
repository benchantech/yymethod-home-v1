# AWS IAM + SSM Setup (Practical)

## Goal
Use AWS IAM for identity and SSM Parameter Store for secrets so the agent never sees raw credentials.

## Architecture
- Agent container: no AWS credentials, no .env, no direct SSM access
- Executor service: attached IAM role
- Secrets stored in SSM Parameter Store (SecureString)
- Executor reads only approved parameter paths

## Recommended SSM Paths
- /app/staging/db/url
- /app/staging/shopify/token
- /app/prod/db/url
- /app/prod/shopify/token

## IAM Policy Pattern
Allow executor role:
- ssm:GetParameter
- ssm:GetParameters
Only for exact ARNs / prefixes needed

Deny:
- ssm:GetParametersByPath on broad roots
- kms decrypt outside needed key
- secretsmanager:* unless explicitly needed later

## Key Rule
Agent never receives:
- raw parameter values
- AWS credentials
- mounted ~/.aws

Executor may return:
- booleans
- summaries
- filtered config
- success/failure
Never raw secret strings

## Example Enforcement
Instead of:
"read /app/prod/shopify/token"

Use:
"deploy_staging"
"validate_shopify_connection"
"fetch_sales_summary"
