# Ambiguity Queue Auto-Parser Design

## Goal
Turn agent ambiguity files into a fast review list for the human.

## Input
Markdown files in /.agent/ambiguities/

## Output
A single summarized review artifact with:
- ID
- short title
- recommendation
- urgency
- blocked area

## Parsing Rules
Extract:
- filename
- Question
- Recommended Option
- Impact

## Suggested Priority Labels
- P0: blocks execution entirely
- P1: blocks deployment or migration
- P2: blocks polish or hardening
- P3: optional improvement

## Human Workflow
1. Open summary
2. Answer one-by-one
3. Write decisions back into /resolved/
4. Agent resumes
