# Multi-Agent Coordination Model

## Purpose
Run parallel agents safely under shared constraints.

## Roles
1. Builder Agent
- writes code
- refactors
- implements features

2. Test Agent
- writes and runs tests
- identifies regressions
- prepares validation reports

3. Review Agent
- checks invariants
- checks flow rules
- flags hidden coupling

4. Docs Agent
- updates ADRs, specs, and operator notes

## Shared Invariants
- no secrets in workspace
- no direct protected actions
- no outbound mutation of protected systems
- all ambiguity goes into queue
- all sensitive execution through executor

## Coordination Pattern
Spec
→ Builder works
→ Test agent validates
→ Review agent checks architecture
→ Docs agent records decisions
→ Human resolves ambiguity batch
→ Executor performs safe actions

## Rule
Agents may work in parallel.
Only executor crosses into sensitive operations.
