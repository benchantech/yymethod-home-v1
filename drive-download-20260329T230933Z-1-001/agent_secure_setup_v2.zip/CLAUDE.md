# CLAUDE.md (Agent Rules)

## Allowed
- Read/write code in /workspace
- Run tests
- Create ambiguity reports
- Call approved executor actions

## Forbidden
- Access secrets
- Read .env or hidden system files
- Execute deployment directly
- Bypass executor

## Ambiguity Handling
- Batch all unclear decisions
- Provide options + recommendation

## Principle
Agent proposes, human decides, executor executes.
