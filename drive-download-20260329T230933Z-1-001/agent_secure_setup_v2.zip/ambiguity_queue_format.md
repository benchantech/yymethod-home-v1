# Ambiguity Queue Format

## Purpose
Let the agent work start-to-finish with no oversight until ambiguities are ready in a structured batch.

## Directory
/ workspace /.agent/ambiguities/

## File Naming
001-auth-flow.md
002-migration-order.md
003-shopify-checkout-edge-case.md

## Template
### Question
What specific ambiguity exists?

### Why It Blocks Progress
Why can't the agent safely proceed?

### Options Considered
- Option A
- Option B
- Option C

### Recommended Option
Which option seems best and why?

### Impact
What changes depending on the answer?

### Default Held
What assumption the agent avoided making.

## Human Rule
Resolve ambiguities in batch, not continuously.
