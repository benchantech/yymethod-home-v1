# Translation Cheat Sheet (Role-Based)

## Core Invariants (everyone)
- Nothing leaves Employer
- Capture first, decide later
- Don’t guess the flow
- Promotion is intentional

---

## Engineering

Focus:
- flows, boundaries, interfaces

Say:
- “Where does this data enter?”
- “Where can it NOT go?”
- “What enforces one-way flow?”

Do:
- make flows explicit
- encode constraints in code
- avoid hidden coupling

Avoid:
- implicit behavior
- bidirectional flows

---

## Product

Focus:
- decisions, tradeoffs, clarity

Say:
- “Where is the decision point?”
- “What is promoted vs discarded?”
- “What happens if this is wrong?”

Do:
- define decision gates
- map user journey to system flow

Avoid:
- feature-first thinking
- skipping decision nodes

---

## Marketing / Growth

Focus:
- behavior, experimentation, outcomes

Say:
- “What can we test here?”
- “Where does the signal come from?”
- “What is the conversion path?”

Do:
- instrument funnels
- run controlled experiments
- track end-to-end journey

Avoid:
- siloed metrics
- disconnected attribution

---

## Ops

Focus:
- reliability, repeatability

Say:
- “What breaks this?”
- “What prevents leakage?”
- “Who owns this step?”

Do:
- enforce invariants
- document handoffs

Avoid:
- ad-hoc processes
- silent exceptions

---

## Non-technical / General

Focus:
- simple rules

Say:
- “Where should this go?”
- “Is this important enough to move in?”

Rules:
- Capture anything
- Only move important things into Employer
- Once in, it stays clean

---

## Coaching Pattern

1. Show example
2. Ask them to place it in the system
3. Let them act
4. Correct only what matters

---

## Quick Phrases (use often)

- “Nothing leaves Employer”
- “Capture first, decide later”
- “Don’t guess the flow”
- “Where does this live?”
- “What gets promoted?”
